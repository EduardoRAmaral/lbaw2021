<?php $__env->startSection('content'); ?>

<style>
  .smaller {
    width: 300px;
    margin-left: 20px;
  }

  .newProduct {
    align-items: center;
  }
</style>


<fieldset>
  <form method="POST" action="<?php echo e(route('newReview.id', ['id' => $order->id])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <Legend>New Review</Legend>
    <div class="form-group row">
      <label for="rating" class="col-sm-2 col-form-label">Score(1-5)*:</label>
      <div class="col-sm-10"></div>
      <input class="form-control-plaintext smaller" id="rating" type="int" name="rating" value="<?php echo e(old('rating')); ?>" pattern="/^[1-5]$/" required autofocus>
    </div>
    <?php if($errors->has('rating')): ?>
    <span class="error">
      <?php echo e($errors->first('rating')); ?>

    </span>
    <?php endif; ?>

    <div class="form-group row">
      <label for="comment" class="col-sm-2 col-form-label">Comment:</label>
      <div class="col-sm-10"></div>
      <input class="form-control-plaintext smaller" id="comment" type="text" name="comment" value="<?php echo e(old('comment')); ?>">
    </div>
    <?php if($errors->has('comment')): ?>
    <span class="error">
      <?php echo e($errors->first('comment')); ?>

    </span>
    <?php endif; ?>

    <button type="submit" class="btn btn-primary">
      Submit
    </button>
    <a class="btn btn-outline-primary" href="<?php echo e(route('newProduct')); ?>">Cancel</a>
  </form>
</fieldset>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/pages/newReview.blade.php ENDPATH**/ ?>