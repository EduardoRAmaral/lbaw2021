<?php $__env->startSection('content'); ?>

<style>
  .smaller {
    width: 300px;
    margin-left: 20px;
  }

  .newProduct {
    align-items: center;
  }
</style>


<fieldset>
  <form method="POST" action="<?php echo e(route('newProduct')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <Legend>New Product</Legend>
    <div class="form-group row">
      <label for="productname" class="col-sm-2 col-form-label">Product Name*</label>
      <div class="col-sm-10"></div>
      <input class="form-control-plaintext smaller" id="productname" type="text" name="productname" value="<?php echo e(old('productname')); ?>" required autofocus>
    </div>
    <?php if($errors->has('productname')): ?>
    <span class="error">
      <?php echo e($errors->first('productname')); ?>

    </span>
    <?php endif; ?>

    <div class="form-group">
      <label for="name" class="form-label mt-4">Category*</label>
      <select class="form-select smaller" id="name" type="name" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($categoryItem->id); ?>"><?php echo e($categoryItem->name); ?></option>
        <?php if($errors->has('name')): ?>
        <span class="error">
          <?php echo e($errors->first('name')); ?>

        </span>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label for="description">Description*</label>
      <input id="description" type="description" name="description" value="<?php echo e(old('description')); ?>" required>
      <?php if($errors->has('description')): ?>
      <span class="error">
        <?php echo e($errors->first('description')); ?>

      </span>
      <?php endif; ?>
    </div>

    <div class="form-group">
      <label for="price">Price</label>
      <input id="price" type="real" name="price" value="<?php echo e(old('price')); ?>" required autofocus>
      <?php if($errors->has('price')): ?>
      <span class="error">
        <?php echo e($errors->first('price')); ?>

      </span>
      <?php endif; ?>
    </div>

    <div class="form-group">
      <label for="pricePerDay">Price per day</label>
      <input id="pricePerDay" type="real" name="pricePerDay" value="<?php echo e(old('pricePerDay')); ?>" required autofocus>
      <?php if($errors->has('pricePerDay')): ?>
      <span class="error">
        <?php echo e($errors->first('pricePerDay')); ?>

      </span>
      <?php endif; ?>
    </div>

    <div class="form-check">
      <label for="active" class="form-check-label">Product active</label>
      <input type="checkbox" class="form-check-input" name="active" checked="yes">
    </div>

    <div class="form-group">
      <label for="img" class="form-label mt-4">Select image to upload:</label>
      <input class="form-control" type="file" name="img" id="img">
    </div>

    <button type="submit" class="btn btn-primary">
      Submit
    </button>
    <a class="btn btn-outline-primary" href="<?php echo e(route('newProduct')); ?>">Cancel</a>
</fieldset>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/products/new.blade.php ENDPATH**/ ?>