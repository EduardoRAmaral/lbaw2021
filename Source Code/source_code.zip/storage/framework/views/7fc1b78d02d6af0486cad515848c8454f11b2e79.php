<form action="/sender" method="post">
    <input type="text" name="text">
    <input type="submit">
    <?php echo e(csrf_field()); ?>

</form><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/messages/sender.blade.php ENDPATH**/ ?>