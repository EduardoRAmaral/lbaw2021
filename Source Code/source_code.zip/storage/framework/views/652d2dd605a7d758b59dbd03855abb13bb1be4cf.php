<?php $__env->startSection('content'); ?>

<style>
  .smaller {
    width: 300px;
    margin-left: 20px;
  }

  .newProduct {
    align-items: center;
  }
</style>


<fieldset>
  <form method="POST" action="<?php echo e(route('newApplication', ['id' => auth()->user()])); ?>">
    <?php echo e(csrf_field()); ?>

    <Legend>New Product</Legend>
    <div class="form-group row">
      <label for="title" class="col-sm-2 col-form-label">Title:</label>
      <div class="col-sm-10"></div>
      <input class="form-control-plaintext smaller" id="title" type="text" name="title" value="<?php echo e(old('title')); ?>" required autofocus>
    </div>
    <?php if($errors->has('title')): ?>
    <span class="error">
      <?php echo e($errors->first('title')); ?>

    </span>
    <?php endif; ?>
    <div class="form-group row">
      <label for="description" class="col-sm-2 col-form-label">Description:</label>
      <div class="col-sm-10"></div>
      <input class="form-control-plaintext smaller" id="description" type="text" name="description" value="<?php echo e(old('description')); ?>" required>
    </div>
    <?php if($errors->has('description')): ?>
    <span class="error">
      <?php echo e($errors->first('description')); ?>

    </span>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">
      Submit
    </button>
    <a class="btn btn-outline-primary" href="<?php echo e(route('newProduct')); ?>">Cancel</a>
</fieldset>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/applications/newApplication.blade.php ENDPATH**/ ?>