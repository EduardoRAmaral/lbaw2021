<?php $__env->startSection('content'); ?>
<title>About</title>

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

<!-- Styles -->
<style>
    .temp1 {
        /*
        background-color: #343434;
        */
        font-family: 'Nunito', sans-serif;
        color: #B9B9B9;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
    }

    #messsage_box {
        width: 400px;
        height: 500px;
        max-height: 400px;
        border-style: solid;
        border-color: black;
        overflow: scroll;
    }

    .message {
        height: 10px;
        color: black;
        margin-left: 5px;
    }

    .message:hover {
        background-color: black;
        color: white;
    }

    .selfMessage {
        background-color: lightblue;
        color: black;
        text-align: right;
        margin-right: 10px;
    }

    .selfMessage:hover {
        background-color: cyan;
    }

    .geral {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        justify-self: center;
        text-align: center;

    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => auth()->user()->id])); ?>">Admin Tools</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(url('/applications')); ?>">Applications Manager</a></li>
    <li class=" breadcrumb-item active">Application</li>
</ol>

<section class="geral">

    <div class="userProfile">
        <div class="card mb-3">
            <h3 class="card-header">Application ID: <?php echo e($application->id); ?></h3>
            <div class="card-body">
                <h5 class="card-title">User ID: <?php echo e($application->userid); ?></h5>
                <h5 class="card-title">Application State: <?php echo e($application->application_state); ?></h5>
                <h5 class="card-title">Title: <?php echo e($application->title); ?></h5>
            </div>
            <ul class="list-group list-group-flush">
                <h5 class="list-group-item">Description: <?php echo e($application->description); ?></h5>
            </ul>
            <div class="card-body">
                <?php if($application->application_state == 'Evaluating'): ?>
                <form method="POST" action="<?php echo e(route('acceptApplication', [$application->id])); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-outline-primary">
                        Accept
                    </button>
                </form>

                <form method="POST" action="<?php echo e(route('rejectApplication', [$application->id])); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-outline-primary">
                        Reject
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/applications/application.blade.php ENDPATH**/ ?>