<?php $__env->startSection('title', 'Cards'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .biggerApplication {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 5px;
    }

    .applications {
        border-radius: 10px;
        background-color: #4ACBC9;
        width: 100px;
        height: 100px;
        color: #343434;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        margin: 5px;
        text-align: center;
    }

    .category:hover {
        background-color: #8AFCFA;
        width: 105px;
        height: 105px;
    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>">User Profile</a></li>
    <li class="breadcrumb-item active">Applications</li>
</ol>

<section id="applications">
    <div class="biggerApplication">
        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('showApplication.id', ['id' => $application->id])); ?>">
            <div class="btn btn-outline-dark" style="margin-left: 5px;"><?php echo e($application -> id); ?></div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/pages/applications.blade.php ENDPATH**/ ?>