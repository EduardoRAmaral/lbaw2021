<?php $__env->startSection('title','Review'); ?>

<?php $__env->startSection('content'); ?>
<style>
  .reviews {
    border-radius: 10px;
    background-color: #4ACBC9;
    width: 100px;
    height: 100px;
    color: #343434;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin: 5px;
  }

  .reviews:hover {
    background-color: #8AFCFA;
    width: 105px;
    height: 105px;
  }

  .userProfile {
    width: 500px;
    margin-left: 15px;
    float: left;
  }

  h2 {
    text-align: center;
  }
</style>

<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
  <?php if($id == auth()->user()->id): ?>
  <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => auth()->user()->id] )); ?>">User Profile</a></li>
  <?php else: ?>
  <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => $id = $reviews[1]->to_user ] )); ?>">User Profile</a></li>
  <?php endif; ?>
  <li class="breadcrumb-item active">Reviews</li>
</ol>

<section id="reviews">
  <h2 class="temp1">Reviews</h2>
  <?php if(Auth::check()): ?>
  <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="userProfile">
    <div class="card mb-3">
      <h3 class="card-header">From: <?php echo e($from); ?></h3>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">Order Number: <?php echo e($review->orderid); ?> </li>
        <li class="list-group-item">Rating: <img src="<?php echo e(asset('uploads/icons/Star_icon.png')); ?>" style="height:15px;width:15px;margin-bottom:5px"></img><?php echo e($review->rating); ?> </li>
        <li class="list-group-item">Comment: <?php echo e($review->comment); ?></li>
        <li class="list-group-item">Date: <?php echo e($review->review_date); ?></li>
      </ul>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/pages/reviews.blade.php ENDPATH**/ ?>