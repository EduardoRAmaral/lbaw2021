<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title','Product Page'); ?>

<!-- Fonts -->
<!-- Styles -->
<link href="<?php echo e(asset('css/reviews.css')); ?>" rel="stylesheet">
<style>
    h2 {
        color: white;
        font-size: 50px;

    }

    footer {
        bottom: -200px;
    }

    .productPicture {
        position: absolute;
        top: 100px;
        left: 0;
        z-index: -1;

        width: 50%;
        min-height: calc(100vh - 100px);
        max-height: calc(100vh);

        background-color: white;

        display: flex;
        align-items: center;
        justify-content: center;

    }

    .productPicture>img {
        width: 100%;
        height: calc(100vh - 100px);
    }

    .productInfo {
        position: absolute;
        padding-left: 50px;
        padding-top: 100px;
        top: 100px;
        right: 0;
        z-index: -1;

        background-color: #1a1a1a;
        color: white;

        width: 50%;
        min-height: calc(100vh - 100px);
    }

    .orderForms {
        padding-top: 30px;
        padding-bottom: 30px;
    }

    .productInfo .nav-link {
        color: white;
    }

    .reviewItem {
        width: 100%;
        height: fit-content;
        margin-right: 50px;
        border-style: solid;
        border-color: white;
        margin-bottom: 10px;
        padding: 5px;
    }

    .breadcrumb-item>a {
        color: white;
    }

    .bottom-div {
        position: absolute;
        bottom: 10%;
        left: 41%;
    }
</style>
<!-- 
{
    "id":3,
    "seller":9,
    "productname":"Iate",
    "description":"Brand new",
    "active":true,
    "price":null,
    "priceperday":"75"
}
-->

<title><?php echo e($product->productname); ?></title>



<section>
    <div class="productPicture">
        <img alt="Imagem do Produto" src="<?php echo e(asset('uploads/productImages/'. $product->img)); ?>" enctype="multipart/form-data">
    </div>

    <div class="productInfo">
        <ol class="breadcrumb" style="position: absolute; top: 0px; right: 40px; width: fit-content; padding-left: 5px; padding-right: 5px;">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/products')); ?>">Products</a></li>
            <li class="breadcrumb-item active">Product</li>
        </ol>
        <h2> <?php echo e($product->productname); ?> </h2>
        <h3 style="color: white;">
            <?php if($product->price != 0 && $product->pricePerDay != 0): ?>
            Price: <?php echo e($product->price); ?>€ | Price: <?php echo e($product->pricePerDay); ?>€
            <?php else: ?>
            <?php if($product->price != 0): ?>
            Price: <?php echo e($product->price); ?>€
            <?php endif; ?>
            <?php if($product->pricePerDay != 0): ?>
            Price: <?php echo e($product->pricePerDay); ?>€
            <?php endif; ?>
            <?php endif; ?>
        </h3>
        <p style="margin-top: -5px;">
            <?php if($product->active): ?>
            <span style="color:lightgreen;">
                Product Available
            </span>
            <?php else: ?>
            <span style="color:red;">
                Product Currently Unavailable
            </span>
            <?php endif; ?>
        </p>

        <div class="orderForms">
            <?php if($product->price != NULL && $product->active== 'true'): ?>
            <form method="post" action="<?php echo e(route('order.create', ['id' => $product->id, 'order_type' => 'Purchase'])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class=" input-group">
                    <button class="btn btn-outline-light" type="submit">
                        Buy
                    </button>
                </div>
            </form>
            <?php endif; ?>
            <?php if($product->priceperday != NULL && $product->active== 'true'): ?>
            <form method="post" action="<?php echo e(route('order.create', ['id' => $product->id, 'order_type' => 'Loan'])); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <button class="btn btn-outline-light" type="submit">
                        Loan
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
        <ul class="nav nav-tabs" style="margin-right: 50px;">
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" id="#Description">Description</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" id="#Profile">Seller</a>
            </li>
            <li>
                <a class="nav-link active" data-bs-toggle="tab" id="#Reviews">Seller Reviews</a>
            </li>
        </ul>
        <div id="myTabContent" class="tab-content" style="margin-right: 50px;">
            <div class="tab-pane fade" id="Description">
                <p><?php echo e($product->description); ?></p>
            </div>
            <div class="tab-pane fade" id="Profile">
                <p><a style="color: white;" href="<?php echo e(route('user.id' , ['id' => $product->seller])); ?>">Seller's Webpage</a></p>

            </div>

            <!--Reviews-->
            <div class="tab-pane fade active show" id="Reviews">
                <?php if(count($reviews)+1 != 1): ?>
                <div class="container">
                    <ul class="hash-list cols-3 cols-1-xs pad-30-all align-center text-sm">
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img src="https://bootdey.com/img/Content/avatar/avatar1.png" class="wpx-100 img-round mgb-20" title="" alt="" data-edit="false" data-editor="field" data-field="src[Image Path]; title[Image Title]; alt[Image Alternate Text]">
                            <p class="fs-110 font-cond-l" contenteditable="false">"<?php echo e($review->comment); ?>"</p>
                            <h5 class="font-cond mgb-5 fg-text-d fs-130" contenteditable="false"><?php echo e($review->from_user); ?></h5><img src="<?php echo e(asset('uploads/icons/Star_icon.png')); ?>" style="height:20px;width:20px;margin-bottom:5px;"></img>
                            <small class="font-cond case-u lts-sm fs-80 fg-text-l" contenteditable="false"><?php echo e($review->rating); ?>/5</small>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <?php if(Auth::check()): ?>
                <div class="bottom-div">
                    <a class="btn btn-outline-light" href="<?php echo e(route('moreReviews', ['id' => $product->seller])); ?>"> More Reviews </a>
                </div>
                <?php endif; ?>
                <?php else: ?>
                <p>No reviews</p>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>
<script>
    navLinks = ["Description", "Profile", "Reviews"]

    document.getElementById("#Description").addEventListener("click", function() {
        hideAllOtherThan("Description")
    });
    document.getElementById("#Profile").addEventListener("click", function() {
        hideAllOtherThan("Profile")
    });
    document.getElementById("#Reviews").addEventListener("click", function() {
        hideAllOtherThan("Reviews")
    });

    function hideAllOtherThan(toShow) {
        document.getElementById("#" + toShow).classList.add("active");
        document.getElementById(toShow).classList.add("show");
        document.getElementById(toShow).classList.add("active");

        for (let navLink of navLinks) {
            if (navLink != toShow) {
                document.getElementById("#" + navLink).classList.remove("active");
                document.getElementById(navLink).classList.remove("show");
                document.getElementById(navLink).classList.remove("active");
            }
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/products/product.blade.php ENDPATH**/ ?>